import * as three from './three.module.js';

// Implement the basic texture file for each block.
const textureLoader = new three.TextureLoader();
const textureAtlas = textureLoader.load('/Assets/Images/Texture-Atlas.png');
textureAtlas.magFilter = three.NearestFilter;
textureAtlas.minFilter = three.NearestFilter;

export class Chunk {
    constructor(scene, three) {
        this.scene = scene;
        this.three = three;
        
        this.width = 32;
        this.height = 16;
        this.depth = 32;
        
        this.chunkData = new Uint8Array(this.width * this.height * this.depth);
        this.generateTerrain();
        
        this.mesh = this.generateMesh();
        this.scene.add(this.mesh);
    }

    // Get block from position Vector3(X, Y, Z)
    getBlock(x, y, z) {
        if (x < 0 || x >= this.width || y < 0 || y >= this.height || z < 0 || z >= this.depth) return 0;
        return this.chunkData[x + y * this.width + z * this.width * this.height];
    }

	// Change a block type at (X, Y, Z) and trigger a mesh rebuild
	setBlock(x, y, z, blockId) {
    	if (x < 0 || x >= this.width || y < 0 || y >= this.height || z < 0 || z >= this.depth) return;

    	const index = x + y * this.width + z * this.width * this.height;
    	this.chunkData[index] = blockId;

    	this.scene.remove(this.mesh);
    	this.mesh.geometry.dispose();
		
    	this.mesh = this.generateMesh();
    	this.scene.add(this.mesh);
	}

    generateTerrain() {
        for (let x=0; x<this.width; x++) {
            for (let z=0; z<this.depth; z++) {
                for (let y=0; y<this.height; y++) {
                    const index = x + (y * this.width) + (z * this.width * this.height);
                    const groundHeight = 7;

                    if (y > groundHeight) {
                        this.chunkData[index] = 0; // Air
                    } else if (y === groundHeight) {
                        this.chunkData[index] = 3; // Grass
                    } else if (y < groundHeight && y >= groundHeight - 2) {
                        this.chunkData[index] = 2; // Dirt
                    } else {
                        this.chunkData[index] = 1; // Stone
                    }
                }
            }
        }
    }

    generateMesh() {
        const positions = [];
        const indices = [];
        const uvs = [];
        let vertexCount = 0;

        const pushUVs = (uMin, uMax, vMin, vMax) => {
            const topV = 1.0 - vMin;
            const botV = 1.0 - vMax;
            uvs.push(
                uMin, topV,
                uMax, topV,
                uMin, botV,
                uMax, botV
            );
        };

        const applyFaceTexture = (blockId, faceDirection) => {
            if (blockId === 1) {
                pushUVs(0.25, 0.5, 0.25, 0.5); // Stone
            } else if (blockId === 2) {
                pushUVs(0.25, 0.5, 0.0, 0.25); // Dirt
            } else if (blockId === 3) {
                if (faceDirection === 'top') {
                    pushUVs(0.0, 0.25, 0.0, 0.25); // Grass Top
                } else if (faceDirection === 'bottom') {
                    pushUVs(0.25, 0.5, 0.0, 0.25); // Dirt Bottom
                } else {
                    pushUVs(0.0, 0.25, 0.25, 0.5); // Grass Side
                }
            } else if (blockId === 4) {
				pushUVs(0.25, 0.0, 0.5, 0.75); // Oak Plank
			}
        };

        for (let x = 0; x < this.width; x++) {
            for (let y = 0; y < this.height; y++) {
                for (let z = 0; z < this.depth; z++) {
                    const blockId = this.getBlock(x, y, z);
                    if (blockId === 0) continue; // Skip air blocks entirely

                    // 1. TOP FACE
                    if (this.getBlock(x, y + 1, z) === 0) {
                        positions.push(
                            x,     y + 1, z,
                            x + 1, y + 1, z,
                            x,     y + 1, z + 1,
                            x + 1, y + 1, z + 1
                        );
                        applyFaceTexture(blockId, 'top');
                        indices.push(vertexCount, vertexCount + 2, vertexCount + 1, vertexCount + 1, vertexCount + 2, vertexCount + 3);
                        vertexCount += 4;
                    }

                    // 2. BOTTOM FACE
                    if (this.getBlock(x, y - 1, z) === 0) {
                        positions.push(
                            x,     y, z,
                            x + 1, y, z,
                            x,     y, z + 1,
                            x + 1, y, z + 1
                        );
                        applyFaceTexture(blockId, 'bottom');
                        indices.push(vertexCount, vertexCount + 1, vertexCount + 2, vertexCount + 1, vertexCount + 3, vertexCount + 2);
                        vertexCount += 4;
                    }

                    // 3. FRONT FACE
                    if (this.getBlock(x, y, z + 1) === 0) {
                        positions.push(
                            x,     y,     z + 1,
                            x + 1, y,     z + 1,
                            x,     y + 1, z + 1,
                            x + 1, y + 1, z + 1
                        );
                        applyFaceTexture(blockId, 'side');
                        indices.push(vertexCount, vertexCount + 1, vertexCount + 2, vertexCount + 1, vertexCount + 3, vertexCount + 2);
                        vertexCount += 4;
                    }

                    // 4. BACK FACE
                    if (this.getBlock(x, y, z - 1) === 0) {
                        positions.push(
                            x + 1, y,     z,
                            x,     y,     z,
                            x + 1, y + 1, z,
                            x,     y + 1, z
                        );
                        applyFaceTexture(blockId, 'side');
                        indices.push(vertexCount, vertexCount + 1, vertexCount + 2, vertexCount + 1, vertexCount + 3, vertexCount + 2);
                        vertexCount += 4;
                    }

                    // 5. RIGHT FACE
                    if (this.getBlock(x + 1, y, z) === 0) {
                        positions.push(
                            x + 1, y,     z + 1,
                            x + 1, y,     z,
                            x + 1, y + 1, z + 1,
                            x + 1, y + 1, z
                        );
                        applyFaceTexture(blockId, 'side');
                        indices.push(vertexCount, vertexCount + 1, vertexCount + 2, vertexCount + 1, vertexCount + 3, vertexCount + 2);
                        vertexCount += 4;
                    }

                    // 6. LEFT FACE
                    if (this.getBlock(x - 1, y, z) === 0) {
                        positions.push(
                            x,     y,     z,
                            x,     y,     z + 1,
                            x,     y + 1, z,
                            x,     y + 1, z + 1
                        );
                        applyFaceTexture(blockId, 'side');
                        indices.push(vertexCount, vertexCount + 1, vertexCount + 2, vertexCount + 1, vertexCount + 3, vertexCount + 2);
                        vertexCount += 4;
                    }
                }
            }
        }

        const geometry = new this.three.BufferGeometry();
        geometry.setAttribute('position', new this.three.Float32BufferAttribute(positions, 3));
        geometry.setAttribute('uv', new this.three.Float32BufferAttribute(uvs, 2));
        geometry.setIndex(indices);
        geometry.computeVertexNormals();
    
        const material = new this.three.MeshStandardMaterial({
            map: textureAtlas,
            wireframe: false,
            side: this.three.FrontSide
        });
    
		const mesh = new this.three.Mesh(geometry, material);
		mesh.castShadow = true;
		mesh.receiveShadow = true;
        return mesh;
    }
}