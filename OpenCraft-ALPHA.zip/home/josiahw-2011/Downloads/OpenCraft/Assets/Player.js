import * as three from './three.module.js'
import { Timer } from './Timer.js';

export class Player {
	constructor (camera, controls) {
		this.camera = camera;
		this.controls = controls;
		
		this.moveSpeed = 10.0;
		this.timer = new three.Timer();
		
		this.keys = {
			forward: false,
			backward: false,
			left: false,
			right: false,
			up: false,
			down: false
		};

		this.initInput();
	}

	initInput() {
		document.addEventListener('keydown', (event) => {
			switch (event.code) {
				case 'KeyW': this.keys.forward = true; break;
				case 'KeyA': this.keys.left = true; break;
				case 'KeyS': this.keys.backward = true; break;
				case 'KeyD': this.keys.right = true; break;
				case 'Space': this.keys.up = true; break;
				case 'ShiftLeft': case 'ShiftRight': this.keys.down = true; break;
			}
		});

		document.addEventListener('keyup', (event) => {
			switch (event.code) {
				case 'KeyW': this.keys.forward = false; break;
				case 'KeyA': this.keys.left = false; break;
				case 'KeyS': this.keys.backward = false; break;
				case 'KeyD': this.keys.right = false; break;
				case 'Space': this.keys.up = false; break;
				case 'ShiftLeft': case 'ShiftRight': this.keys.down = false; break;
			}
		});
	}

	update() {
		this.timer.update();
		
		const delta = this.timer.getDelta();
		
		if (this.controls.isLocked) {
			const distance = this.moveSpeed * delta;

			if (this.keys.forward) this.controls.moveForward(distance);
			if (this.keys.backward) this.controls.moveForward(-distance);
			if (this.keys.right) this.controls.moveRight(distance);
			if (this.keys.left) this.controls.moveRight(-distance);
			
			if (this.keys.up) this.camera.position.y += distance;
			if (this.keys.down) this.camera.position.y -= distance;
		}
	}
}